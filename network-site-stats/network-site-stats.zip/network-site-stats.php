<?php
/**
 * Plugin Name: Network Site Stats
 * Description: Thống kê ID, Tên, Số bài viết và Ngày đăng bài mới nhất của các site con.
 * Version: 1.1
 * Author: [NGuyễn Hữu Thành]
 */

if (!defined('ABSPATH'))
    exit;

class Network_Site_Stats
{

    public function __construct()
    {
        add_action('network_admin_menu', array($this, 'add_stats_menu'));
    }

    public function add_stats_menu()
    {
        add_menu_page(
            'Thống kê mạng lưới',
            'Network Stats',
            'manage_network',
            'network-site-stats-slug',
            array($this, 'render_stats_page'),
            'dashicons-chart-area',
            30
        );
    }

    public function render_stats_page()
    {
        $sites = get_sites();

        echo '<div class="wrap">';
        echo '<h1>Bảng theo dõi tình trạng các trang web con</h1>';
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead>
                <tr>
                    <th style="width: 50px;">ID</th>
                    <th>Tên trang web (Blog Name)</th>
                    <th>Số lượng bài viết</th>
                    <th>Ngày đăng bài mới nhất</th>
                </tr>
              </thead>
              <tbody>';

        foreach ($sites as $site) {
            $blog_id = $site->blog_id;


            switch_to_blog($blog_id);

            $site_info = get_blog_details($blog_id);

            $post_count = wp_count_posts()->publish;


            $recent_post = wp_get_recent_posts(array(
                'numberposts' => 1,
                'post_status' => 'publish',
            ));
            $last_date = (!empty($recent_post)) ? $recent_post[0]['post_date'] : 'Chưa có bài';


            restore_current_blog();

            echo "<tr>
                    <td>{$blog_id}</td>
                    <td><strong>{$site_info->blogname}</strong></td>
                    <td>{$post_count} bài viết</td>
                    <td>{$last_date}</td>
                  </tr>";
        }

        echo '</tbody></table></div>';
    }
}

new Network_Site_Stats();